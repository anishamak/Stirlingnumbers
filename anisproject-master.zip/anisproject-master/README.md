# anisproject
Le projet suivant porte sur la création initdev et le nom de mon projet . 
Pour éviter tout malentendu le dossier "initialisation du dépot git" a été emprunté a un site ; 
Mon projet est nommé initdev anisproject les autres étant des codes révisés un peu partout 
